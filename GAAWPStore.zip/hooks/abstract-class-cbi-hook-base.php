<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 
 * 
 * Class CBI_Hook_Base
 */
abstract class CBI_Hook_Base {
	
	public function __construct() {}
	
}